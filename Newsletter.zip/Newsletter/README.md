# Ejercicio 1 : Newsletter

---

- Jesus Acosta Zuñiga:
- 22151182:

---

## 📌 Descripción


Hice una pagina web para poder suscribirte a Newsletter, esta tiene un diseño simple 
para poder suscribirte te pide un correo para que este te mande informes sobre la subcripcion
cuando pones el correo te da un mensaje de que esta correcto.

## 🚀 Tecnologías utilizadas
- HTML  
- CSS  
- Otro: 

---

## 🔗 Enlace al proyecto
Repositorio en GitHub: [Pega aquí tu enlace]  
Deploy: [Pega aquí el deploy de GitHub Pages]
---

## 📝 Reflexión
Lo unico con lo que se me complico fue con el diseño, que no quedaba como yo querian los botones y que con los botones no tenian la funcion de reconocer el click
todo eso lo resolvi viendo tutoriales.
