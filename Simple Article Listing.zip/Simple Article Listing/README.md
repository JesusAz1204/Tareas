# Ejercicio 1 : Newsletter

---

- Nombre: 
- Número de Control:

---

## 📌 Descripción



---

## 🚀 Tecnologías utilizadas
- HTML  
- CSS  
- Otro: 

---

## 🔗 Enlace al proyecto
Repositorio en GitHub:  (https://github.com/JesusAz1204/Tareas)
Deploy: [LINK](http://yomidev.github.io/newsletter/)
---

## 📝 Reflexión
(Escribe aquí unas líneas sobre lo que aprendiste, las dificultades que tuviste y cómo las solucionaste)
